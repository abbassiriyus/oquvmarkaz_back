
var express = require('express');
var router = express.Router();
var jwt = require('jsonwebtoken');
const pool = require("../db")
var {ensureToken,ensureTokenSuper,ensureTokenTeacher,superTeacher }=require("../token/token.js")

router.get('/mark/task/:id', (req, res) => {
    pool.query("SELECT * FROM course_theme_task_student where feedback=$1", [req.params.id], (err, result) => {
        if (!err) {
            res.status(200).send(result.rows)
        } else {
            res.status(400).send(err)
        }
    })
})
router.get('/mark/test/:id', (req, res) => {
    pool.query("SELECT * FROM attendance_test where student_id=$1", [req.params.id], (err, result) => {
        if (!err) {
            res.status(200).send(result.rows)
        } else {
            res.status(400).send(err)
        }
    })
})

router.get('/mark/lesson/:id', (req, res) => {
    pool.query("SELECT * FROM attendance_lesson where student_id=$1", [req.params.id], (err, result) => {
        if (!err) {
            res.status(200).send(result.rows)
        } else {
            res.status(400).send(err)
        }
    })
})

module.exports = router;